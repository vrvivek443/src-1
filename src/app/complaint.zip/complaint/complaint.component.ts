import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MockupViewModel } from '../mockpage/mockup.viewmodel';
import { APIURLConstant } from '../api.url.constant';
import { ComplaintService } from '../services/complaint.service';
import { ViolationViewModel } from '../violations/violation.viewmodel';
import { ActionLogAppointmentViewModel, ActionLogCitiationViewModel, ActionLogPictureViewModel, ActionLogTypeViewModel, ActionLogViewModel, CaseAddress, caseAddressViewModel, CaseDetailViewModel, casePersonViewModel, CaseViewModel, CaseViolationViewModel, City, SearchViewModel, ViolationDataViewModel } from './complaint.viewmodel';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { mustMatch } from '../validators/compare-values'

declare var jQuery: any;
declare var stepper1: any;
declare var bstreeview: any;
declare var Lobibox: any;
declare var lightbox: any;

@Component({
  selector: 'app-complaint',
  templateUrl: './complaint.component.html',
  styleUrls: ['./complaint.component.css']
})
export class ComplaintComponent {
  public userProfileDataList: any;
  _phone1typeerro: any = "errmesag";
  _addressListTbl: any;
  _personTbl: any;
  _personTable: any;
  _isEdit: boolean = false;
  _messageText: string;
  _searchViewModel: SearchViewModel;
  _selectedAPN: string;
  _caseAddressViewModel: caseAddressViewModel;
  _caseDetailViewModel: CaseDetailViewModel;
  _caseDetail: any;
  _caseDetailForm: FormGroup;
  _caseViewModel: CaseViewModel;
  _caseAddress: CaseAddress;
  _caseAddressForm: FormGroup;
  _casePersonViewModel: casePersonViewModel;
  _caseViolationViewModel: CaseViolationViewModel;
  _actionLogViewModel: ActionLogViewModel;
  _selectedActionLogViewModel: any;
  _actionLogTypeViewModel: ActionLogTypeViewModel;
  _citationViewModel: ActionLogCitiationViewModel;
  _actionLogFileViewModel: any;
  _actionLogPictureViewModel: ActionLogPictureViewModel;
  _actionLogForm: FormGroup;
  _casePersonForm: FormGroup;
  _caseViolationForm: FormGroup;
  _actionLogAppointmentViewModel: ActionLogAppointmentViewModel;
  _actionLogAppointmentForm: FormGroup;
  _actionLogTaskForm: FormGroup;
  _selectedItem: any;
  _caseAddressId: number;
  _caseId: number;
  _mockupViewModel: MockupViewModel;
  _primaryInspectorAssignment: string;
  _secondaryInspectorAssignment: string;
  searchText: string;
  street: string;
  jsonData: any;
  _personType: any[] = [];
  _currentStepIndex: number;
  jsonSourceData: any;
  _masterDataList: any[] = [];
  _areaTypeDataList: any[] = [];
  _complaintTypeDataList: any[] = [];
  _coreServiceTypeDataList: any[] = [];
  _dispositionTypeDataList: any[] = [];
  _phoneTypeDataList: any[] = [];
  _priorityTypeDataList: any[] = [];
  _programTypeDataList: any[] = [];
  _relationshipTypeDataList: any[] = [];
  _salutationTypeDataList: any[] = [];
  _personTypeDataList: any[] = [];
  _serviceAreaTypeDataList: any[] = [];
  _streetTypeDataList: any[] = [];
  _streetMasterDataList: any[] = [];
  _actionListDataList: any[] = [];
  _sourceDataList: any[] = [];
  _cdbgDataList: any[] = [];
  _caseStatusTypeDataList: any[] = [];
  _taskStatusTypeDataList: any[] = [];
  _actionTypeDataList: any[] = [];
  _primaryInspectorDataList: any[] = [];
  _secondaryInspectorDataList: any[] = [];
  _violationStatusTypeDataList: any[] = [];
  _enableSave: boolean;
  _addressSearchResultDataList: any[] = [];
  _caseHistoryDataList: any[] = [];
  _viewAddressDetail: any;
  salutation: string;
  _violationDataList: any[] = [];
  _personDataList: any[] = [];
  _violation: ViolationDataViewModel;
  _caseHistoryList: any[];
  _inspectorList: any[] = [];
  _caseViolationDataList: any[] = [];
  // Version
  _personVersion: number;
  _violationVersion: number;
  _selectedViolationID: number;
  _actionVersion: number;
  _actionFileContentAsString: string;
  _actionFileName: string;
  _pictureFileName: string;
  imgData: any;
  audioData: any;
  videoData: any;
  _imageBaseURL: string;
  _pictureDescription: string;
  _audioDescription: string;
  _videoDescription: string;
  pictures: any[] = [];
  audios: any[] = [];
  videos: any[] = [];
  constructor(private _http: HttpClient, private _fb: FormBuilder, private _urlConstant: APIURLConstant, private _complaintServiceCall: ComplaintService, private router: Router, private _activatedRoute: ActivatedRoute) {

  }

  ngOnInit() {
    this._pictureDescription = "";
    this._audioDescription = "";
    this._videoDescription = "";
    this._pictureFileName = "";
    this._imageBaseURL = this._urlConstant.APIBaseURL + this._urlConstant.CaseMasterModule + this._urlConstant.streamFileForActionFile + "?"
    jQuery('#nextPersonBtn').hide();
    lightbox.option({
      'resizeDuration': 200,
      'wrapAround': true
    })
    this.resetSearchViewModel();
    this.resetCaseAddressViewModel();
    this.resetCasePersonViewModel();
    this.resetCaseDetailViewModel();
    this.resetViolationViewModel();
    this.resetActionLogViewModel();
    this.resetCitationViewModel();
    this.resetActionLogTypeViewModel();
    this.resetActionLogAppointmentViewModel();
    this.loadMasterData();
    jQuery("#violation-list").show();
    jQuery("#violation-add-edit").hide();
    jQuery("#addOrEditPerson").hide();
    jQuery("#addOrEditViolation").hide();
    jQuery("#addOrEditAction").hide();
    jQuery("#action-add-edit").hide();
    jQuery("#actionGrid").show();
    jQuery("#frmActionLog").show();

    this.salutation = "";
    this.view(1);
    this._caseAddressId = -1;
    this._caseId = 0;
    this._currentStepIndex = 1;
    this.searchText = "";
    this._enableSave = false;
    this._activatedRoute.queryParamMap.subscribe((q: any) => {
      var lowerParams = this.toLower(q.params);
      var caseid = lowerParams['caseid'];
      if (caseid != null && caseid != undefined)
        this.getCaseByID(lowerParams['caseid']);
    })
    jQuery('#single-select-optgroup-field').select2({
      theme: "bootstrap-5",
      width: jQuery(this).data('width') ? jQuery(this).data('width') : jQuery(this).hasClass('w-100') ? '100%' : 'style',
      placeholder: jQuery(this).data('placeholder'),
    });

    if (localStorage.getItem("nc") == "yes") {
      localStorage.setItem("nc", "no");
      location.reload()
    }
    let self: any = this;
    this._personTable = jQuery('#personTable').DataTable({
      columns: [
        { data: 'personType' },
        { data: 'firstName' },
        { data: 'relationShip' },
        { data: 'address1' },
        { data: 'email' },
        { data: 'phone1' }
      ],
      columnDefs: [
        {
          targets: 0,
          data: 'personType',
          render: function (data: any, type: any, row: any, meta: any) {
            return self.getMasterData(self._urlConstant.PersonType, data);
          }
        },
        {
          targets: 1,
          data: 'firstName',
          render: function (data: any, type: any, row: any, meta: any) {
            return `${row.firstname} ${row.middlename} ${row.lastname}`;
          }
        },
        {
          targets: 2,
          data: 'relationship',
          render: function (data: any, type: any, row: any, meta: any) {
            return self.getMasterData(self._urlConstant.RelationshipType, row.relationship);
          }
        },
        {
          targets: 3,
          data: 'relationship',
          render: function (data: any, type: any, row: any, meta: any) {
            return `${self.getString(row.address1)} ${self.getString(row.address2)} ${self.getString(row.city)}`;
          }
        },
        {
          targets: 4,
          data: 'email',
          render: function (data: any, type: any, row: any, meta: any) {
            if (!self.isNull(row.email))
              return `<a href="mailto:${row.email}">${row.email}</a>`;
            else
              return "";
          }
        }
        ,
        {
          targets: 5,
          data: 'phone1',
          render: function (data: any, type: any, row: any, meta: any) {
            if (!self.isNull(row.phone1))
              return `<a href="tel:${row.phone1}">${row.phone1} ${self.getMasterData(self._urlConstant.PhoneType, row.phone1type)}</a>`;
            else
              return "";
          }
        }

      ]
    });

    this._personTable.on('click', 'tbody tr', (e: any) => {
      let classList = e.currentTarget.classList;

      if (classList.contains('selected')) {
        classList.remove('selected');
      }
      else {
        self._personTable.rows('.selected').nodes().each((row: any) => row.classList.remove('selected'));
        classList.add('selected');
      }
    });
    jQuery('.selectcontrol1').select2({ width: '100%' });
    // jQuery('.selectcontrol').select2({ width: '100%' });
    this._primaryInspectorAssignment = "";
    this._secondaryInspectorAssignment = "";
    this.resetMockViewModel();
    const url: string = "/assets/MOCK_DATA.json";
    jQuery("#caseHistoryReport").hide();
    jQuery("#propertyAndCaseHistory").hide();
    //jQuery("#addressInfo").hide();
    jQuery("#registeredCases").hide();



    jQuery('#receiveddate').prop('max', new Date().toISOString().split("T")[0]);
    jQuery('#cudate').prop('min', new Date().toISOString().split("T")[0]);
    jQuery('#opendate').prop('max', new Date().toISOString().split("T")[0]);
    jQuery('#closedate').prop('min', new Date().toISOString().split("T")[0]);
    jQuery('#duedate').prop('min', new Date().toISOString().split("T")[0]);
    this._http.get(url).subscribe((response) => {
      this.userProfileDataList = response;
    });
  }
  toLower(params: Params): Params {
    const lowerParams: Params = {};
    for (const key in params) {
      lowerParams[key.toLowerCase()] = params[key];
    }

    return lowerParams;
  }
  ngAfterViewInit() {

  }
  getString(obj: any) {
    if (this.isNull(obj))
      return "";
    else
      return obj;
  }
  loadCaseHistory() {
    let opt: any = {
      "apn": [this._viewAddressDetail.apn]
    };
    this._complaintServiceCall.searchByObjectParameter(this._urlConstant.CaseMasterModule, this._urlConstant.Search, opt).subscribe((response) => {

    });
  }
  loadMasterData() {
    this._masterDataList = [];
    this._complaintServiceCall.get(this._urlConstant.CategoryModule, this._urlConstant.GetAll).subscribe((response) => {
      this._masterDataList = response.data;
      this._areaTypeDataList = [];
      this._complaintTypeDataList = [];
      this._coreServiceTypeDataList = [];
      this._dispositionTypeDataList = [];
      this._phoneTypeDataList = [];
      this._priorityTypeDataList = [];
      this._programTypeDataList = [];
      this._relationshipTypeDataList = [];
      this._salutationTypeDataList = [];
      this._serviceAreaTypeDataList = [];
      this._streetTypeDataList = [];
      this._personTypeDataList = [];
      this._sourceDataList = [];
      this._caseStatusTypeDataList = [];
      this._taskStatusTypeDataList = [];
      this._masterDataList.forEach(e => {
        if (e.status) {
          switch (e.category) {
            case this._urlConstant.CaseStatusType:
              this._caseStatusTypeDataList.push(e);
              break;
            case this._urlConstant.SourceType:
              this._sourceDataList.push(e);
              break;
            case this._urlConstant.AreaType:
              this._areaTypeDataList.push(e);
              break;
            case this._urlConstant.ComplaintType:
              this._complaintTypeDataList.push(e);
              break;
            case this._urlConstant.CoreServiceType:
              this._coreServiceTypeDataList.push(e);
              break;
            case this._urlConstant.DispositionType:
              this._dispositionTypeDataList.push(e);
              break;
            case this._urlConstant.PhoneType:
              this._phoneTypeDataList.push(e);
              break;
            case this._urlConstant.PriorityType:
              this._priorityTypeDataList.push(e);
              break;
            case this._urlConstant.ProgramType:
              this._programTypeDataList.push(e);
              break;
            case this._urlConstant.RelationshipType:
              this._relationshipTypeDataList.push(e);
              break;
            case this._urlConstant.SalutationType:
              this._salutationTypeDataList.push(e);
              break;
            case this._urlConstant.ServiceAreaType:
              this._serviceAreaTypeDataList.push(e);
              break;
            case this._urlConstant.StreetType:
              this._streetTypeDataList.push(e);
              break;
            case this._urlConstant.PersonType:
              this._personTypeDataList.push(e);
              this._personType.push(e.value);
              break;
            case this._urlConstant.CBDGType:
              this._cdbgDataList.push(e);
              break;
            case this._urlConstant.ActionType:
              this._actionTypeDataList.push(e);
              break;
            case this._urlConstant.ViolationStatusType:
              this._violationStatusTypeDataList.push(e);
              break;
            case this._urlConstant.TaskStatus:
              this._taskStatusTypeDataList.push(e);
              break;
          }
        }
      });
      console.log(JSON.stringify(this._cdbgDataList));
    });

    this._complaintServiceCall.get(this._urlConstant.StreetMasterModule, this._urlConstant.GetAll).subscribe((response) => {
      this._streetMasterDataList = [];
      if (response.status == "SUCCESS") {
        this._streetMasterDataList = response.data;
      } else {
        console.log("Unable to receive Street Master Data : " + response.errorMessage)
      }
    });


    this._complaintServiceCall.get(this._urlConstant.ActionModule, this._urlConstant.GetAll).subscribe((response) => {
      this._actionListDataList = [];
      if (response.status == "SUCCESS") {
        this._actionListDataList = response.data;
      } else {
        console.log("Unable to receive Street Master Data : " + response.errorMessage)
      }
    });

    this._complaintServiceCall.get(this._urlConstant.ViolationTypeModule, this._urlConstant.GetAll).subscribe((response) => {
      console.log("Violation Response : " + JSON.stringify(response.data));
      this._violationDataList = [];
      this._violationDataList = response.data;
      this.jsonData = [];
      this._violationDataList.forEach(e => {
        this._violation = {
          text: "",
          children: []
        }
        let violationChildDataList = [];
        violationChildDataList = e.violations;
        this._violation.text = e.violationdescr;
        violationChildDataList.forEach((e1: any) => {
          return this._violation.children.push({ "id": e1.id, "text": e1.municipalcode + " " + e1.shortdesc });
        });
        this.jsonData.push({
          "text": e.violationdescr, "children": this._violation.children
        });
        //console.log("JSONData : " + JSON.stringify(this.jsonData));
      });
      let vsid = 0;
      this._selectedViolationID = vsid;
      let self = this;
      jQuery('#violationList')
        .on("changed.jstree", function (e: any, data: any) {
          if (data.selected.length) {
            //            vsid = data.instance.get_node(data.selected[0]).id;
            //jQuery("#_selectedViolationID").val(data.instance.get_node(data.selected[0]).id);
            // alert('The selected node is: ' + data.instance.get_node(data.selected[0]).id);
            self.onViolationSelection(data.instance.get_node(data.selected[0]).id);
          }
        })
        .jstree({
          'core': {
            'multiple': false,
            'data': this.jsonData
          }, 'search': {
            'show_only_matches': true,
            'show_only_matches_children': true
          },
          "plugins": ["search"]
        });



    });

    this._complaintServiceCall.get(this._urlConstant.UserDataModule, this._urlConstant.GetAllInspector).subscribe((response) => {
      console.log("Response : " + JSON.stringify(response.data));
      this._inspectorList = [];
      this._inspectorList = response.data;
    });
  }
  isNull(d: any) {
    return d == null || d == undefined;
  }
  openImage() {
    alert("Okay . . . ")
  }
  getCaseByID(id: any) {
    this._complaintServiceCall.getByModuleMethodAndParameter(this._urlConstant.CaseMasterModule, this._urlConstant.GetByID, "id=" + id).subscribe((response) => {
      this._caseHistoryList = [];
      if (response.status == "SUCCESS") {
        console.log("Case Detail : " + JSON.stringify(response));
        this._caseDetail = response.data[0];
        if (JSON.stringify(this._caseDetail).includes("caseaddress")) {
          this._viewAddressDetail = response.data[0].caseaddress;
        }
        console.log("Address Detail : " + JSON.stringify(this._viewAddressDetail));
        jQuery(".tab-page").removeAttr("disabled");
        Lobibox.notify('success', {
          pauseDelayOnHover: true,
          continueDelayOnInactiveTab: false,
          position: 'top right',
          icon: 'bx bx-check-circle',
          msg: 'Case Loaded Successfully. Case ID = ' + id
        });
        this._personDataList = response.data[0].casePerson;
        this._caseId = response.data[0].id;
        // this._caseAddressId = response.data[0].caseaddress.id;
        this._enableSave = true;
        this._personTable.clear().rows.add(this._personDataList).draw();
        this._personTable.draw();
        this.resetCaseDetailViewModel();
        this._caseDetailViewModel = this._caseDetail;
        jQuery('#createCaseBtn').hide();
        jQuery('#nextPersonBtn').show();

      } else {
        console.log("Unable to receive Case Address : " + response.errorMessage)
      }
    });
  }

  getActionName(code: string) {
    let item: any = this._actionListDataList.filter((itm) => (itm.actionCode == code))
    // console.log("Item " + JSON.stringify(item));
    if (item != null) {
      return item[0].actionDescription;
    } else {
      return "";
    }
  }

  getInspectorName(id: number) {
    let item: any = this._inspectorList.filter((itm) => (itm.id == id))
    if (item != null) {
      return item.name;
    } else {
      return "";
    }
  }


  getMasterData(category: String, value: String) {
    let x: any = this._masterDataList.find((c: any) => c.category == category && c.code == value);
    if (x != null)
      return x.value;
    return value;
  }
  showActionComments(id: any) {
    if (jQuery("#row" + id).hasClass("d-none")) {
      jQuery("#row" + id).removeClass("d-none");
    } else {
      jQuery("#row" + id).addClass("d-none");
    }
  }
  onViolationSelection(selectedID: any) {
    this._selectedViolationID = selectedID;
    this._violationDataList.forEach(e => {
      let violationChildDataList = [];
      violationChildDataList = e.violations;
      violationChildDataList.forEach((e1: any) => {
        if (e1.id == selectedID) {
          console.log("Element : " + JSON.stringify(e1));
          this._caseViolationViewModel.correctiveaction = e1.correctiveaction;
          this._caseViolationViewModel.violation = e1.shortdesc;
          this._caseViolationViewModel.municode = e1.municipalcode;
          this._caseViolationViewModel.description = e1.fulldesc;
          this._caseViolationViewModel.violationtype = e1.violationtypecode;

        }
      });
    });
  }

  searchAddress() {
    let searchParameter = [];
    let formHasValue = false;
    if (this._searchViewModel.apartmentNumber.length > 0) {
      formHasValue = true;
      searchParameter.push("apartmentNumber=" + this._searchViewModel.apartmentNumber);
    }
    if (this._searchViewModel.apnNumber.length > 0) {
      formHasValue = true;
      searchParameter.push("apnNumber=" + this._searchViewModel.apnNumber);
    }
    /*     if (this._searchViewModel.streetName.length > 0) {
          searchParameter.push("streetName=" + this._searchViewModel.streetName);
        } */
    if (this._searchViewModel.streetType.length > 0) {
      formHasValue = true;
      let stData: any = this._streetMasterDataList.find(x => x.id == this._searchViewModel.streetType);

      searchParameter.push("streetType=" + stData.streetTypeCode);
      searchParameter.push("streetName=" + stData.streetname);
    }
    if (this._searchViewModel.streetNumber.length > 0) {
      formHasValue = true;
      searchParameter.push("streetNumber=" + this._searchViewModel.streetNumber);
    }
    if (formHasValue == true) {
      this.loadAddress(searchParameter.join("&"));
    } else {
      Lobibox.notify('error', {
        pauseDelayOnHover: true,
        continueDelayOnInactiveTab: false,
        position: 'top right',
        icon: 'bx bx-check-circle',
        msg: 'Please input any one field value.'
      });
    }

  }

  selectAddress(_address: any) {
    //this._caseAddressViewModel = _address;
    this._viewAddressDetail = _address;
    jQuery("#SearchResultAddress").modal("hide");

  }

  getCaseHistoryOfSelectedAddressAPN() {
    let search = {
      "apn": [
        this._caseAddressViewModel.APN
      ]
    }
    this._complaintServiceCall.searchByObjectParameter(this._urlConstant.CaseMasterModule, this._urlConstant.Search, search).subscribe((response) => {
      console.log("Case History Data List : " + JSON.stringify(response));
      this._caseHistoryList = [];
      if (response.status == "SUCCESS") {
        this._caseDetail = response.data[0];

      } else {
        console.log("Unable to receive Case Address : " + response.errorMessage)
      }
    });
  }

  selectedAddress() {
    this._caseAddressViewModel = this._viewAddressDetail;
    jQuery("#SearchResultAddress").modal("hide");
  }

  showAddressList() {
    jQuery("#addressDetail").hide();
    jQuery("#addressList").show();
  }
  loadAddress(parameter: string) {
    let self = this;
    console.log("Search Parameter : " + parameter);
    this._caseAddressViewModel = null;
    this._viewAddressDetail = null;
    this._complaintServiceCall.getByModuleMethodAndParameter(this._urlConstant.CityAddressModule, this._urlConstant.GetAddressByFields, parameter).subscribe((response) => {
      console.log("Address : " + JSON.stringify(response));
      this._addressSearchResultDataList = [];
      if (response.status == "SUCCESS") {
        this._addressSearchResultDataList = response.data;
        if (this._addressSearchResultDataList.length > 1) {
          jQuery("#addressDetail").hide();
          jQuery("#addressList").show();
          if (this._addressListTbl === undefined) {
            this._addressListTbl = jQuery("#addressList").DataTable({
              columns: [
                { data: 'apn' },
                { data: 'address' },
                { data: 'district' },
                { data: 'state' },
                { data: 'zipcode' },
                {
                  data: null,
                  title: 'Action',
                  width: '100px',
                  defaultContent: '<button id="btnSelect" class="btn btn-primary">Select</button> <button id="btnView" class="btn btn-primary">View</button>',
                  orderable: false
                }
              ],
              columnDefs: [
                { className: "dt-center", targets: [0, 1, 2, 3, 4, 5] },
                {
                  targets: 0,
                  data: 'apn',
                  render: function (data: any, type: any, row: any, meta: any) {
                    return `${row.apn}`;
                  }
                }, {
                  targets: 1,
                  data: 'address',
                  className: 'dt-left',
                  render: function (data: any, type: any, row: any, meta: any) {
                    return `${row.streetNumber} ${row.streetName} ${row.streetType}`;
                  }
                },
                {
                  targets: 2,
                  data: 'district',
                  render: function (data: any, type: any, row: any, meta: any) {
                    return `${row.district}`;
                  }
                },
                {
                  targets: 3,
                  data: 'state',
                  render: function (data: any, type: any, row: any, meta: any) {
                    return `${row.state}`;
                  }
                },
                {
                  targets: 4,
                  data: 'zip',
                  render: function (data: any, type: any, row: any, meta: any) {
                    return `${row.zip}`;
                  }
                }
                // ,
                // {
                //   targets: 5,
                //   data: 'action',
                //   render: function (data: any, type: any, row: any, meta: any) {
                //     return `${row.zip}`;
                //   }
                // }
              ]
            });
          }
          this._addressListTbl.clear().rows.add(this._addressSearchResultDataList).draw();
          this._addressListTbl.draw();
          jQuery("#SearchResultAddress").modal("show");
          jQuery(document).ready(function () {
            jQuery('#addressList tbody').on('click', "#btnSelect", function (this: any, e: any) {
              var row = jQuery(this).parents('tr')[0];
              console.log('Row Data:', row);
              console.log(self._addressListTbl.rows(row).data()[0].id);
              self.selectAddress(self._addressListTbl.rows(row).data()[0]);
            });
            jQuery('#addressList tbody').on('click', "#btnView", function (this: any, e: any) {
              var row = jQuery(this).parents('tr')[0];
              console.log('Row Data:', row);
              console.log(self._addressListTbl.rows(row).data()[0].id);
              self.viewAddress(self._addressListTbl.rows(row).data()[0]);
            });
          });
        } else if (this._addressSearchResultDataList.length == 1) {
          this._caseAddressViewModel = this._addressSearchResultDataList[0];
          this._viewAddressDetail = this._addressSearchResultDataList[0];
        } else {
          this._messageText = "No address found for the search criteria.";
          jQuery("#messageBox").modal("show");
        }

      } else {
        console.log("Unable to receive Case Address : " + response.errorMessage)
      }
    });
  }
  viewAddress(_addressDetail: any) {
    jQuery("#addressDetail").show();
    jQuery("#addressList").hide();
    this._viewAddressDetail = _addressDetail;
  }
  resetMockViewModel() {
    this._mockupViewModel = {
      id: 0,
      first_name: "",
      last_name: "",
      email: ""
    }
  }
  resetCaseAddressViewModel() {
    this._caseAddressViewModel = {
      id: 0,
      APN: "",
      buildingpermit: "",
      censusTract: "",
      district: "",
      houseNumber: "",
      housingpermit: "",
      lastinspectionrtndate: null,
      noofunits: 0,
      ownerCityStateZip: "",
      ownerName: "",
      ownerPhone: "",
      ownerStreet: "",
      planningpermit: "",
      policebeat: "",
      policedistrict: "",
      propertycomment: "",
      propertytype: "",
      streetName: "",
      streetType: "",
      taxratearea: "",
      trashpickupday: "",
      trashputoutday: "",
      zoningresearch: "",
    };
    this._caseAddressForm = this._fb.group({
      id: [0, Validators.required],
      apn: ["", Validators.required],
      buildingpermit: ["", Validators.required],
      censustract: ["", Validators.required],
      district: ["", Validators.required],
      houseNumber: ["", Validators.required],
      housingpermit: ["", Validators.required],
      lastinspectionrtndate: [null, Validators.required],
      noofunits: [0, Validators.required],
      ownerCityStateZip: ["", Validators.required],
      ownerName: ["", Validators.required],
      ownerPhone: ["", Validators.required],
      ownerStreet: ["", Validators.required],
      planningpermit: ["", Validators.required],
      policebeat: ["", Validators.required],
      policedistrict: ["", Validators.required],
      propertycomment: ["", Validators.required],
      propertytype: ["", Validators.required],
      streetName: ["", Validators.required],
      streetType: ["", Validators.required],
      taxratearea: ["", Validators.required],
      trashpickupday: ["", Validators.required],
      trashputoutday: ["", Validators.required],
      zoningresearch: ["", Validators.required],
    });
  }

  resetViolationViewModel() {
    this._caseViolationViewModel = {
      id: -1,
      inspectionVersion: 0,
      area: "",
      closedate: "",
      correctiveaction: "",
      description: "",
      duedate: "",
      municode: "",
      opendate: "",
      priority: "",
      status: false,
      violation: "",
      violationstatus: "",
      violationtype: "",
      createdBy: "",
      createdOn: "",
      modifiedBy: "",
      modifiedOn: "",
      caseMaster: {},
    };
    let status = this._violationStatusTypeDataList.find((x: any) => x.isDefault == true);
    if (status !== null && status !== undefined) {
      this._caseViolationViewModel.violationstatus = status.code;
    }
    this._caseViolationForm = this._fb.group({
      id: [0],
      inspectionVersion: [0],
      area: [""],
      closedate: [""],
      correctiveaction: [""],
      description: [""],
      duedate: [""],
      municode: [""],
      opendate: [""],
      priority: [""],
      status: [false],
      violation: [""],
      violationstatus: [""],
      violationtype: [""],
      createdBy: [""],
      createdOn: [""],
      modifiedBy: [""],
      modifiedOn: [""],
    });

  }

  resetActionLogTypeViewModel() {
    this._actionLogTypeViewModel = {
      id: 0,
      actionCode: "",
      actionDate: "",
      actionType: "",
      actionVersion: 0,
      caseMaster: {},
      caseActionFiles: [],
      comments: "",
      createdBy: "",
      createdOn: new Date().toISOString().split("T")[0],
      isRead: false,
      modifiedBy: "",
      modifiedOn: "",
      readDate: "",
      routeToInspectorId: 0,
      startDate: new Date().toISOString().split("T")[0],
      endDate: new Date().toISOString().split("T")[0],
      subject: "",
      taskStatus: "",
      status: false
    }
    this._actionLogTaskForm = this._fb.group({
      id: [0],
      actionCode: [""],
      actionDate: [""],
      actionType: [""],
      actionVersion: [0],
      caseMaster: {},
      comments: [""],
      createdBy: [""],
      createdOn: [""],
      isRead: [false],
      modifiedBy: [""],
      modifiedOn: [""],
      readDate: [""],
      startDate: [""],
      endDate: [""],
      subject: [""],
      taskStatus: [""],
      routeToInspectorId: [0],
      status: [false]
    });

  }


  resetActionLogAppointmentViewModel() {
    this._actionLogAppointmentViewModel = {
      id: 0,
      actionCode: "",
      actionDate: "",
      actionType: "",
      actionVersion: 0,
      caseMaster: {},
      caseActionFiles: [],
      comments: "",
      createdBy: "",
      createdOn: new Date().toISOString().split("T")[0],
      isRead: false,
      modifiedBy: "",
      modifiedOn: "",
      readDate: "",
      routeToInspectorId: 0,
      startDate: new Date().toISOString().split("T")[0],
      endDate: new Date().toISOString().split("T")[0],
      subject: "",
      location: "",
      status: false
    }
    this._actionLogAppointmentForm = this._fb.group({
      id: [0],
      actionCode: [""],
      actionDate: [""],
      actionType: [""],
      actionVersion: [0],
      caseMaster: {},
      comments: [""],
      createdBy: [""],
      createdOn: [""],
      isRead: [false],
      modifiedBy: [""],
      modifiedOn: [""],
      readDate: [""],
      startDate: [""],
      endDate: [""],
      subject: [""],
      location: [""],
      routeToInspectorId: [0],
      status: [false]
    });
  }


  resetActionLogPictureViewModel() {
    this._actionLogPictureViewModel = {
      id: 0,
      description: "",
      fileData: "",
      filename: "",
      physicalfilename: ""
    };
  }
  resetActionLogViewModel() {
    this._actionLogViewModel = {
      id: 0,
      actionCode: "",
      actionDate: "",
      actionType: "",
      actionVersion: 0,
      caseMaster: {},
      caseActionFiles: [],
      comments: "",
      createdBy: "",
      createdOn: new Date().toISOString().split("T")[0],
      isRead: false,
      modifiedBy: "",
      modifiedOn: "",
      readDate: "",
      routeToInspectorId: 0,
      status: false
    };
    this._actionLogForm = this._fb.group({
      id: [0],
      actionCode: [""],
      actionDate: [""],
      actionType: [""],
      actionVersion: [0],
      caseMaster: {},
      comments: [""],
      createdBy: [""],
      createdOn: [""],
      isRead: [false],
      modifiedBy: [""],
      modifiedOn: [""],
      readDate: [""],
      startDate: [""],
      endDate: [""],
      subject: [""],
      taskStatus: [""],
      routeToInspectorId: [0],
      status: [false]
    });
    this._selectedActionLogViewModel = null;
    this.pictures = [];
    this.audios = [];
    jQuery("#updateViolation").hide();
    jQuery("#followUpAction").hide();
  }
  resetCitationViewModel() {
    this._citationViewModel = {
      id: 0,
      actionCode: "",
      actionDate: "",
      actionType: "",
      actionVersion: 0,
      amount: 0,
      caseActionFiles: [],
      artype: "",
      caseMaster: {},
      citiationComments: "",
      citiationDate: "",
      citiationNo: "",
      citiedById: 0,
      comments: "",
      createdBy: "",
      createdOn: "",
      fdept: "",
      ffbj: "",
      ffund: "",
      frc: "",
      isRead: false,
      licenseno: "",
      modifiedBy: "",
      modifiedOn: "",
      municode: "",
      readDate: "",
      ref1: "",
      ref2: "",
      routeToInspectorId: 0,
      status: true
    };
    jQuery("#updateViolation").hide();
    jQuery("#followUpAction").hide();
  }
  resetActionLogFileViewModel() {

  }
  resetCaseDetailViewModel() {
    this._caseDetailViewModel = {
      id: 0,
      caseaddress: null,
      casestatus: "D",
      cdbgcasetype: "",
      closedate: "",
      coreservicecode: "",
      createdby: "",
      createdon: "",
      cudate: "",
      description: "",
      dispositioncode: "",
      inspector1id: null,
      inspector2id: null,
      modifiedby: "",
      modifiedon: "",
      opendate: "",
      prioritycode: "",
      programcode: "",
      receiveddate: new Date().toISOString().split("T")[0],
      sourcecode: "",
      hasCasedetail: true,
      version: 0
    }
    this._caseDetailForm = this._fb.group({
      id: [0],
      caseaddress: [null],
      casestatus: [""],
      cdbgcasetype: [""],
      closedate: [""],
      coreservicecode: [""],
      createdby: [""],
      createdon: [""],
      cudate: [""],
      description: [""],
      dispositioncode: [""],
      inspector1id: [null],
      inspector2id: [null],
      modifiedby: [""],
      modifiedon: [""],
      opendate: [""],
      prioritycode: [""],
      programcode: [""],
      hasCasedetail: [true],
      receiveddate: [""],
      sourcecode: [""],
      version: [0]
    })
  }
  resetCasePersonViewModel() {
    this._casePersonViewModel = {
      id: 0,
      firstname: "",
      middlename: "",
      lastname: "",
      address1: "",
      address2: "",
      email: "",
      phone1: "",
      phone1type: "",
      phone2: "",
      phone2type: "",
      personVersion: 0,
      status: false,
      caseMaster: {},
      comment: "",
      personType: "",
      isEditable: true,
      relationship: "",
      salutation: "",
      city: "San Jose",
      state: "CA",
      zip: "",
      createdBy: "",
      createdOn: "",
      modifiedOn: "",
      modifiedBy: "",
    }
    this._casePersonForm = this._fb.group({
      address1: ["", Validators.required],
      address2: ["", Validators.required],
      createdBy: ["", Validators.required],
      createdOn: [null, Validators.required],
      email: ["", Validators.required],
      firstname: ["", Validators.required],
      id: [0, Validators.required],
      isEditable: [true],
      lastname: ["", Validators.required],
      middlename: ["", Validators.required],
      modifiedBy: ["", Validators.required],
      modifiedOn: [null, Validators.required],
      personVersion: [0, Validators.required],
      phone1: ["", Validators.required],
      phone1type: ["", Validators.required],
      phone2: ["", Validators.required],
      phone2type: ["", Validators.required],
      status: [false, Validators.required]
    })
  }

  resetSearchViewModel() {
    this._searchViewModel = {
      apartmentNumber: "",
      streetName: "",
      streetNumber: "",
      streetType: "",
      apnNumber: ""
    }
  }
  resetCaseViewModel() {
    this._caseAddress = {
      apn: "",
      id: -1
    };
    this._caseViewModel = {
      id: -1,
      caseaddress: this._caseAddress,
      hasCasedetail: false,
      version: 0
    }
  }

  onStreetSelect() {
    console.log(this.street);
  }

  search() {
    let to = false;
    if (to) { clearTimeout(to); }
    setTimeout(function () {
      var v = $('#search').val();
      jQuery('#violationList').jstree(true).search(v);
    }, 250);
    jQuery('#violationList').jstree(true).search(this.searchText);
    // this.jsonSourceData.forEach(element => {
    //   console.log(element.text.toString().toLowerCase().indexOf(this.searchText))
    //   if (element.text.toString().toLowerCase().indexOf(this.searchText) != -1) {
    //     this.jsonData.push(element);
    //     jQuery('#violationList').jstree(true).refresh();
    //   }
    // });

  }

  view(id: any) {
    if (id == 1) {
      jQuery("#v1").show();
      jQuery("#v2").hide();
    } else {
      jQuery("#v1").hide();
      jQuery("#v2").show();
    }
  }
  onPrimaryInspectorChange(evt: any) {
    this._primaryInspectorAssignment = " Assigned: 4, In Progress: 6, Closed: 10 (Last 30 days)";
  }

  categoryOnChange(evt: any) {

    switch (evt.target.value) {
      case "F":
        {
          jQuery("#updateViolation").hide();
          jQuery("#followUpAction").hide();
          jQuery("#citationDetails").hide();
          jQuery("#taskDetails").hide();
          jQuery("#appointmentInformations").hide();
          jQuery("#picture").hide();
          jQuery("#audio").hide();
          jQuery("#video").hide();
          this.resetActionLogViewModel();
        }
        break;
      case "I":
        {
          jQuery("#updateViolation").show();
          jQuery("#followUpAction").show();
          jQuery("#citationDetails").hide();
          jQuery("#taskDetails").hide();
          jQuery("#picture").hide();
          jQuery("#audio").hide();
          jQuery("#video").hide();
          jQuery("#appointmentInformations").hide();
        }
        break;
      case "C":
        {
          jQuery("#updateViolation").hide();
          jQuery("#followUpAction").hide();
          jQuery("#citationDetails").show();
          jQuery("#taskDetails").hide();
          jQuery("#picture").hide();
          jQuery("#audio").hide();
          jQuery("#video").hide();
          jQuery("#appointmentInformations").hide();
        }
        break;
      case "T":
        {
          jQuery("#updateViolation").hide();
          jQuery("#followUpAction").hide();
          jQuery("#citationDetails").hide();
          jQuery("#appointmentInformations").hide();
          jQuery("#picture").hide();
          jQuery("#audio").hide();
          jQuery("#video").hide();
          jQuery("#taskDetails").show();
        }
        break;
      case "A":
        {
          jQuery("#updateViolation").hide();
          jQuery("#followUpAction").hide();
          jQuery("#citationDetails").hide();
          jQuery("#taskDetails").hide();
          jQuery("#picture").hide();
          jQuery("#audio").hide();
          jQuery("#video").hide();
          jQuery("#appointmentInformations").show();
          this.resetActionLogAppointmentViewModel();
        }
        break;
      case "P":
        {
          jQuery("#updateViolation").hide();
          jQuery("#followUpAction").hide();
          jQuery("#citationDetails").hide();
          jQuery("#taskDetails").hide();
          jQuery("#appointmentInformations").hide();
          jQuery("#picture").show();
          jQuery("#pictureGallery").hide();
          jQuery("#pictureList").show();
          jQuery("#audio").show();
          jQuery("#audioList").show();
          jQuery("#video").show();
          jQuery("#videoList").show();

          this.resetActionLogAppointmentViewModel();
        }
        break;
    }
  }

  actionOnChange(evt: any) {
    console.log("Item : " + JSON.stringify(evt.target.value));
    let item: any = this._actionListDataList.filter((q) => q.actionCode == evt.target.value);

    if (item != null) {
      switch (item[0].actionType) {
        case "I":
          {
            jQuery("#updateViolation").show();
            jQuery("#followUpAction").show();
            jQuery("#citationDetails").hide();
            jQuery("#taskDetails").hide();
            jQuery("#appointmentInformations").hide();
            jQuery("#picture").hide();
            jQuery("#audio").hide();
            jQuery("#video").hide();
          }
          break;
        case "F":
          {
            jQuery("#updateViolation").hide();
            jQuery("#followUpAction").hide();
            jQuery("#citationDetails").hide();
            jQuery("#taskDetails").hide();
            jQuery("#appointmentInformations").hide();
            jQuery("#picture").hide();
            jQuery("#audio").hide();
            jQuery("#video").hide();
            this.resetActionLogViewModel();
          }
          break;
        case "C":
          {
            jQuery("#updateViolation").hide();
            jQuery("#followUpAction").hide();
            jQuery("#citationDetails").show();
            jQuery("#taskDetails").hide();
            jQuery("#picture").hide();
            jQuery("#audio").hide();
            jQuery("#video").hide();
            jQuery("#appointmentInformations").hide();
            this.resetCitationViewModel();
          }
          break;
        case "T":
          {
            jQuery("#updateViolation").hide();
            jQuery("#followUpAction").hide();
            jQuery("#citationDetails").hide();
            jQuery("#taskDetails").show();
            jQuery("#picture").hide();
            jQuery("#audio").hide();
            jQuery("#video").hide();
            jQuery("#appointmentInformations").hide();
            this.resetActionLogTypeViewModel();
          }
          break;
        case "A":
          {
            jQuery("#updateViolation").hide();
            jQuery("#followUpAction").hide();
            jQuery("#citationDetails").hide();
            jQuery("#taskDetails").hide();
            jQuery("#picture").hide();
            jQuery("#audio").hide();
            jQuery("#video").hide();
            jQuery("#appointmentInformations").show();
            this.resetActionLogAppointmentViewModel();
          }
          break;
        case "P":
          {
            jQuery("#updateViolation").hide();
            jQuery("#followUpAction").hide();
            jQuery("#citationDetails").hide();
            jQuery("#taskDetails").hide();
            jQuery("#appointmentInformations").hide();
            jQuery("#picture").show();
            jQuery("#pictureGallery").hide();
            jQuery("#pictureList").show();
            jQuery("#audio").show();
            jQuery("#pictureList").show();
            jQuery("#video").show();
            jQuery("#videoList").show();
            this.resetActionLogAppointmentViewModel();
          }
          break;
      }
      // if (item[0].actionType == "I") {
      //   jQuery("#updateViolation").show();
      //   jQuery("#followUpAction").show();
      // } else {
      //   jQuery("#updateViolation").hide();
      //   jQuery("#followUpAction").hide();
      // }
      this._actionLogViewModel.actionType = item[0].actionType;
    }
  }

  onFocusOut(e: any) {
    console.log('Phone1type:', e.target.value);
    // let phone1typevalue = false;
    // if (e.target.value.length > 0) {
    //   jQuery(document).ready(function () {

    //   });
    // }
  }

  onProgramCodeChange(evt: any) {
    this.getInspectorByProgramCodeAndCensusTract(evt.target.value, this._viewAddressDetail.censusTract);
  }
  onSecondaryInspectorChange(evt: any) {
    this._secondaryInspectorAssignment = " Assigned: 2, In Progress: 2, Closed: 6 (Last 30 days)";
  }
  getInspectorByProgramCodeAndCensusTract(programCode: string, censustract: string) {
    try {
      let parameter = "censusTract=" + censustract + "&programCode=" + programCode;
      console.log("Parameter : " + parameter);
      this._complaintServiceCall.getByModuleMethodAndParameter(this._urlConstant.CaseDataModule, this._urlConstant.GetInspectorsForProgram, parameter).subscribe((response) => {
        console.log("Parameter : " + JSON.stringify(response));
        this._primaryInspectorDataList = [];
        if (response.status == "SUCCESS") {
          if (response.inspectors != null && response.inspectors.length > 0)
            //$('#inspector1id').val(response.inspectors[0].id);
            this._caseDetailViewModel.inspector1id = response.inspectors[0].id;
        } else {
          Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Unable to receive Primary and Secondary Inspector list based on Census Tract and Program Code.'
          });
          console.log("Unable to receive Inspector Data List : " + response.errorMessage)
        }
      });
    } catch (error) {
      console.log("Error in receiving Inspector : " + JSON.stringify(error))
    }
  }
  hideRegisteredCases() {
    jQuery("#registeredCases").hide();
  }
  getRegisteredCases() {
    jQuery("#registeredCases").show();
  }
  createCase(index: any) {
    if (this._viewAddressDetail != null) {
      this._selectedAPN = this._viewAddressDetail.apn;
      this._messageText = "Do you want to create case for the APN:" + this._selectedAPN;
      jQuery("#messageDialogBox").modal("show");
    } else {
      this._messageText = "Please select an address to create a case.";
      jQuery("#messageBox").modal("show");
    }


  }
  _actionType: number = 0;
  _newViolationAction: number = 1;
  _editVilationAction: number = 2;
  _newPersonAction: number = 3;
  _editPersonAction: number = 4;
  save() {
    let actionCompleted = false;
    /*     switch (this._currentStepIndex) {
          case 2:
            this._casePersonViewModel.isEditable = true;
            actionCompleted=true;
            this.savePerson();
            return;
          case 3:
            actionCompleted=true;
            return;
          
        } */
    jQuery("#messageEditDialogBox").modal("hide");
    switch (this._actionType) {
      case this._newViolationAction:
        this._isEdit = false;
        this.addNewViolation();
        break;
      case this._editVilationAction:
        this._isEdit = false;
        this.editViolation(this._editData);
        break;
      case this._newPersonAction:
        this._isEdit = false;
        this.addNewPerson();
        break;
      case this._editPersonAction:
        this._isEdit = false;
        this.editPersonForTable();
        break;

    }
  }
  openPersonTab() {
    this.resetCasePersonViewModel();
    let nindex = 2;
    this._currentStepIndex = nindex;
    jQuery(".bs-stepper-pane").removeClass("active");
    jQuery(".step").removeClass("active");
    jQuery(".bs-stepper-pane").removeClass("dstepper-block");
    jQuery("#step-l-" + nindex).addClass(" active ");
    jQuery("#step-l-" + nindex).addClass(" dstepper-block ");
    jQuery(".step").removeClass("active");
    $("div[data-target='#step-l-" + nindex + "']").addClass(" active ");
    jQuery("#stepper1trigger" + nindex).removeAttr("disabled");
    jQuery("#personList").show();
    jQuery("#addOrEditPerson").hide();
  }
  createCaseInDraftMode() {
    this.resetCaseViewModel();
    this._caseAddress.apn = this._selectedAPN;
    this._caseAddress.id = -1;
    this._caseViewModel.id = - 1;
    this._caseViewModel.caseaddress = this._caseAddress;
    this._caseViewModel.hasCasedetail = false;
    this._caseViewModel.version = 0;
    console.log("Draft Case Detail : " + JSON.stringify(this._caseViewModel));
    try {
      this._complaintServiceCall.save(this._urlConstant.CaseMasterModule, this._caseViewModel).subscribe((response) => {
        console.log("Case Details : " + JSON.stringify(response));
        jQuery("#btnMDClose").click();
        if (response.status == "SUCCESS") {
          this._caseDetail = response.data[0];
          this._personDataList = response.data[0].casePerson;
          Lobibox.notify('success', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Case saved as Draft.'
          });
          this._caseId = response.data[0].id;
          this._caseAddressId = response.data[0].caseaddress.id;
          this._enableSave = true;

          //this._personDataList = (this._caseDetail[0].casePerson.filter((e: any) => e.status));
          this._personTable.clear().rows.add(this._personDataList).draw();
          this._personTable.draw();


          jQuery("#messageDialogBox").modal("hide");
          this.openPersonTab();
          jQuery('#createCaseBtn').hide();
          jQuery('#nextPersonBtn').show();
          this.createResponsiblePerson(this._viewAddressDetail);
        } else {
          alert("Unable to save case in draft. Please contact IT Helpdesk.");
          Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Unable to save case in draft. Please contact IT Helpdesk.'
          });
        }
      },
        (error) => {
          Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Unable to save case in draft. Please contact IT Helpdesk.'
          });
        });
    } catch (error) {
      Lobibox.notify('error', {
        pauseDelayOnHover: true,
        continueDelayOnInactiveTab: false,
        position: 'top right',
        icon: 'bx bx-check-circle',
        msg: 'Unable to save case in draft. Please contact IT Helpdesk.'
      });
    }
  }
  createResponsiblePerson(caseAddress: any) {
    if (caseAddress.ownername != null) {
      if (caseAddress.ownername.length > 1) {
        this.resetCasePersonViewModel();
        this._casePersonViewModel.address1 = caseAddress.ownerstreet;
        this._casePersonViewModel.address2 = caseAddress.ownercitystatezip;
        this._casePersonViewModel.firstname = caseAddress.ownername;
        this._casePersonViewModel.personType = this._urlConstant.PersonTypeResponsiblePerson;
        this._casePersonViewModel.salutation = "MR.";
        this._casePersonViewModel.lastname = "N/A";
        this._casePersonViewModel.relationship = "TEN";
        this._casePersonViewModel.isEditable = false;
        //this.savePerson();
      }
      if (caseAddress.othername != null) {
        if (caseAddress.othername.length > 1) {
          this.resetCasePersonViewModel();
          this._casePersonViewModel.address1 = caseAddress.otheraddress;
          this._casePersonViewModel.address2 = caseAddress.othercitystatezip;
          this._casePersonViewModel.firstname = caseAddress.ownername;
          this._casePersonViewModel.personType = this._urlConstant.PersonTypeResponsiblePerson;
          this._casePersonViewModel.salutation = "MR.";
          this._casePersonViewModel.lastname = "N/A";
          this._casePersonViewModel.relationship = "TEN";
          this._casePersonViewModel.isEditable = false;
          // this.savePerson();
        }
      }
    }
  }
  cancelSavePerson() {
    jQuery("#personList").show();
    jQuery("#addOrEditPerson").hide();
    jQuery("#navigationPerson").show();
    jQuery('.nav-tabs a[href="#person-list"]').tab('show');
    this.resetCasePersonViewModel();
    this._isEdit = false;
  }

  cancelViolation() {
    // jQuery("#violationGrid").show();
    // jQuery("#frmViolation").hide();
    // jQuery("#navigationViolation").show();
    jQuery("#violationGrid").show();
    jQuery("#addOrEditViolation").hide();
    jQuery("#navigationPerson").show();
    jQuery('.nav-tabs a[href="#violation-list"]').tab('show');
    this.resetViolationViewModel();
    this._isEdit = false;
  }

  loadCaseDetail(caseID: any) {
    try {
      this._complaintServiceCall.getByID(this._urlConstant.CaseMasterModule, this._urlConstant.GetByID, caseID).subscribe((response) => {
        this._caseDetail = null;
        // console.log("Case Detail : " + JSON.stringify(response));
        this._personDataList = [];
        if (response.status == "SUCCESS") {
          this._caseDetail = response.data;
          console.log("Case Details Version" + JSON.stringify(this._caseDetail));
          this._personDataList = [];
          this._personDataList = (this._caseDetail.casePerson.filter((e: any) => e.status));
          console.log("Person Data List : " + JSON.stringify(this._personDataList));
          // this._personDataList = this._caseDetail[0].casePerson;
          let versionList = []
          versionList = this._caseDetail.caseVersions;
          for (var i = 0; i < versionList.length; i++) {
            switch (versionList[i].objecttype) {
              case "Person":
                this._personVersion = versionList[i].version;
                console.log(versionList[i].version)
                break;
            }
          }
        } else {
          Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Unable to receive case details. Please contact IT Helpdesk.'
          });
        }
      });
    } catch (error) {
      console.log("Case Detail : " + JSON.stringify(error));
    }
  }
  personTypeChanged() {
    if (this._casePersonViewModel.personType == "R") {
      $("#relationshipInput").hide();
    } else {
      $("#relationshipInput").show();
    }
  }

  savePerson() {

    if (this._casePersonViewModel.id == 0) {
      this._casePersonViewModel.id = -1;
    }
    this._casePersonViewModel.caseMaster = { "id": this._caseId };
    this._casePersonViewModel.personVersion = (this.getVersion("Person") != -1) ? this._personVersion : 0;
    console.log("casePerson : " + JSON.stringify(this._casePersonViewModel));
    try {
      this._complaintServiceCall.saveByMethodName(this._urlConstant.CaseMasterModule, this._urlConstant.SavePerson, this._casePersonViewModel).subscribe((response) => {
        if (response.status == "SUCCESS") {
          // this.loadCaseDetail(this._caseId);
          Lobibox.notify('success', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Person Information saved successfully.'
          });
          console.log("Save People Response : " + JSON.stringify(response));
          jQuery("#personList").show();
          jQuery("#addOrEditPerson").hide();
          jQuery("#navigationPerson").show();
          jQuery('.nav-tabs a[href="#person-list"]').tab('show');
          this.resetCasePersonViewModel();
          this._personDataList = [];
          this._caseDetail = response.data[0];
          this._personDataList = (this._caseDetail.casePerson.filter((e: any) => e.status));


          console.log("Save Person Response : " + JSON.stringify(response));
          this.resetCasePersonViewModel();
          this._enableSave = true;
          this._personTable.clear().rows.add(this._personDataList).draw();
          this._isEdit = false;
        } else {
          //   alert("Unable to save people information. Please contact IT Helpdesk.");
          let err: [] = JSON.parse(response.errorMessage);
          let errM: any = err.join('<br/>');
          Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Unable to save people information.<br/>' + errM
          });
        }
      },
        (error) => {
          Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Unable to save people information. Please contact IT Helpdesk.'
          });
        });
    } catch (error) {
      Lobibox.notify('error', {
        pauseDelayOnHover: true,
        continueDelayOnInactiveTab: false,
        position: 'top right',
        icon: 'bx bx-check-circle',
        msg: 'Unable to save people information. Please contact IT Helpdesk.'
      });
    }



  }

  saveViolation() {
    try {
      console.log("Violation Starts")
      this._caseViolationViewModel.caseMaster = { "id": this._caseId };
      this._caseViolationViewModel.inspectionVersion = (this.getVersion("Violation") != -1) ? this._violationVersion : 0;
      console.log("Violation View Model : " + JSON.stringify(this._caseViolationViewModel));
      this._complaintServiceCall.saveByMethodName(this._urlConstant.CaseMasterModule, this._urlConstant.SaveViolation, this._caseViolationViewModel).subscribe((response) => {
        console.log("Save Violation Version  Response : " + JSON.stringify(response));
        if (response.status == "SUCCESS") {
          this._caseDetail = response.data[0];
          Lobibox.notify('success', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Violation saved successfully.'
          });
          console.log("Case Detail Response : " + JSON.stringify(response));
          jQuery("#violationGrid").show();
          jQuery("#addOrEditViolation").hide();
          jQuery("#navigationViolation").show();
          jQuery('.nav-tabs a[href="#violation-list"]').tab('show');

          // jQuery("#violationGrid").show();
          // jQuery("#frmViolation").hide();
          // jQuery("#navigationViolation").show();
          this._enableSave = true;
          this.resetViolationViewModel();
          this._isEdit = false;
        } else {
          alert("Unable to save case details : " + response.errorMessage);
          Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Unable to save Violation. Please contact IT Helpdesk.'
          });
        }
      },
        (error) => {
          Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Unable to save violation. Please contact IT Helpdesk.'
          });
        });
    } catch (error) {
      Lobibox.notify('error', {
        pauseDelayOnHover: true,
        continueDelayOnInactiveTab: false,
        position: 'top right',
        icon: 'bx bx-check-circle',
        msg: 'Unable to save Violation information. Error : ' + error
      });
    }
  }

  onSourceType(e: any): string {
    let err: string;
    if (e.length > 0) {

      err = '';
      JSON.parse(e).forEach((v: any) => {
        err += v.split(' ')[0] + ','
      })
      err = err.trimEnd() + ' cannot be null';
      return err;
    }
    return null;
  }

  saveCaseDetail() {
    console.log("Case ID : " + this._caseId);
    console.log("Case Address ID : " + this._caseAddressId);
    this._caseDetailViewModel.id = this._caseId;
    this._caseDetailViewModel.caseaddress = { "id": this._caseAddressId, "apn": this._viewAddressDetail.apn };
    this._caseDetailViewModel.hasCasedetail = true;
    this._caseDetailViewModel.cdbgcasetype = "V";
    //this._caseDetailViewModel.inspector1id=jQuery('#')
    console.log("Case Details : " + JSON.stringify(this._caseDetailViewModel));
    try {
      this._complaintServiceCall.saveByMethodName(this._urlConstant.CaseMasterModule, this._urlConstant.Save, this._caseDetailViewModel).subscribe((response) => {
        if (response.status == "SUCCESS") {
          Lobibox.notify('success', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Case Detail saved successfully.'
          });
          console.log("Case Detail Response : " + JSON.stringify(response));
          this._enableSave = true;
        } else {
          //alert("Unable to save case details. Please contact IT Helpdesk.");
          Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: this.onSourceType(response.errorMessage)
          });
        }
      },
        (error) => {
          Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Unable to case detail information. Please contact IT Helpdesk.'
          });
        });
    } catch (error) {
      Lobibox.notify('error', {
        pauseDelayOnHover: true,
        continueDelayOnInactiveTab: false,
        position: 'top right',
        icon: 'bx bx-check-circle',
        msg: 'Unable to save case detail information. Please contact IT Helpdesk.'
      });
    }
  }
  isAudio(obj: any) {
    if (obj.filename.toLowerCase().endsWith("mp3")) {
      return false;
    } else {
      return true;
    }
  }
  getImageURL(obj: any) {
    if (obj.id == -1) {
      return obj.fileData;
    } else {
      return this._imageBaseURL + "caseId=" + this._caseId + "&actionId=" + this._selectedActionLogViewModel?.id + "&actionFileId=" + obj?.id;
    }
  }
  editPicture(pic: any) {
    this.imgData = this._imageBaseURL + "caseId=" + this._caseId + "&actionId=" + this._selectedActionLogViewModel?.id + "&actionFileId=" + pic?.id
    this._pictureDescription = pic.description;
    jQuery("#pictureUploadMDL").modal("show");
  }
  editAudio(aud: any) {
    this.audioData = this._imageBaseURL + "caseId=" + this._caseId + "&actionId=" + this._selectedActionLogViewModel?.id + "&actionFileId=" + aud?.id
    this._pictureDescription = aud.description;
    jQuery("#audioUploadMDL").modal("show");
  }
  editVideo(vid: any) {
    this.videoData = this._imageBaseURL + "caseId=" + this._caseId + "&actionId=" + this._selectedActionLogViewModel?.id + "&actionFileId=" + vid?.id
    this._pictureDescription = vid.description;
    jQuery("#videoUploadMDL").modal("show");
  }
  editAction(action: any) {
    this._selectedActionLogViewModel = action;
    console.log("Selectec Action : " + JSON.stringify(action));
    jQuery("#addOrEditAction").show();
    switch (this._selectedActionLogViewModel.actionType) {
      case "I":
        {
          jQuery("#updateViolation").show();
          jQuery("#followUpAction").show();
          jQuery("#citationDetails").hide();
          jQuery("#taskDetails").hide();
          jQuery("#picture").hide();
          jQuery("#audio").hide();
          jQuery("#video").hide();
          jQuery("#appointmentInformations").hide();
        }
        break;
      case "F":
        {
          this._actionLogViewModel = this._selectedActionLogViewModel;
          jQuery("#action-add-edit").show();
          jQuery("#addOrEditAction").show();
          jQuery("#updateViolation").hide();
          jQuery("#followUpAction").hide();
          jQuery("#citationDetails").hide();
          jQuery("#picture").hide();
          jQuery("#audio").hide();
          jQuery("#video").hide();
          jQuery("#taskDetails").hide();
          jQuery("#appointmentInformations").hide();
        }
        break;
      case "C":
        {
          this._citationViewModel = this._selectedActionLogViewModel;
          this._actionLogViewModel = this._selectedActionLogViewModel;
          console.log("Citation Action Log : " + JSON.stringify(this._citationViewModel));
          console.log("Action Log : " + JSON.stringify(this._actionLogViewModel));

          jQuery("#action-add-edit").show();

          jQuery("#updateViolation").hide();
          jQuery("#followUpAction").hide();
          jQuery("#citationDetails").show();
          jQuery("#picture").hide();
          jQuery("#audio").hide();
          jQuery("#video").hide();
          // jQuery("#actionAddOrEdit").show();
          // jQuery("#action-add-edit").show();
          jQuery("#taskDetails").hide();
          jQuery("#appointmentInformations").hide();
        }
        break;
      case "T":
        {
          this._actionLogTypeViewModel = this._selectedActionLogViewModel;
          this._actionLogViewModel = this._selectedActionLogViewModel;

          jQuery("#action-add-edit").show();
          jQuery("#updateViolation").hide();
          jQuery("#followUpAction").hide();
          jQuery("#citationDetails").hide();
          jQuery("#picture").hide();
          jQuery("#audio").hide();
          jQuery("#video").hide();
          jQuery("#appointmentInformations").hide();
          jQuery("#taskDetails").show();
        }
        break;
      case "A":
        {
          this._actionLogAppointmentViewModel = this._selectedActionLogViewModel;
          this._actionLogViewModel = this._selectedActionLogViewModel;

          jQuery("#action-add-edit").show();
          jQuery("#updateViolation").hide();
          jQuery("#followUpAction").hide();
          jQuery("#citationDetails").hide();
          jQuery("#picture").hide();
          jQuery("#audio").hide();
          jQuery("#video").hide();
          jQuery("#taskDetails").hide();
          jQuery("#appointmentInformations").show();
        }
        break;
      case "P":
        {
          this._actionLogPictureViewModel = this._selectedActionLogViewModel;
          this._actionLogViewModel = this._selectedActionLogViewModel;
          this.pictures = this._selectedActionLogViewModel.caseActionFiles.filter((itm: any) => ((!itm.filename.endsWith(".mp3") && (!itm.filename.endsWith(".mp4")))));
          this.audios = this._selectedActionLogViewModel.caseActionFiles.filter((itm: any) => (itm.filename.endsWith(".mp3")));
          this.videos = this._selectedActionLogViewModel.caseActionFiles.filter((itm: any) => (itm.filename.endsWith(".mp4")));
          console.log("Picture : " + JSON.stringify(this._actionLogPictureViewModel));
          jQuery("#action-add-edit").show();
          jQuery("#updateViolation").hide();
          jQuery("#followUpAction").hide();
          jQuery("#citationDetails").hide();
          jQuery("#taskDetails").hide();
          jQuery("#appointmentInformations").hide();
          jQuery("#pictureContent").show();
          jQuery("#pictureList").show();
          jQuery("#picture").show();
          jQuery("#audioContent").show();
          jQuery("#audioList").show();
          jQuery("#audio").show();
          jQuery("#videoList").show();
          jQuery("#video").show();
        }
        break;
    }
    jQuery("#navigationAction").hide();
    jQuery('.nav-tabs a[href="#actionAddOrEdit"]').tab('show');
    jQuery('.nav-tabs a[href="#action-add-edit"]').tab('show');
  }


  addPictureToList() {

    console.log("Data Started . . .");
    this.resetActionLogPictureViewModel();
    //  this._actionLogPictureViewModel = this._actionLogViewModel;
    // console.log(this.imgData);
    //console.log((this.imgData.startsWith("data")) ? this.imgData.split(",")[1] : "");
    this._actionLogPictureViewModel.fileData = this.imgData; //(this.imgData.startsWith("data")) ? this.imgData.split(",")[1] : "";
    this._actionLogPictureViewModel.filename = this._pictureFileName;
    console.log("Data Started . . .1");
    this._actionLogPictureViewModel.description = this._pictureDescription;
    this._actionLogPictureViewModel.id = -1;
    console.log("Data " + JSON.stringify(this._actionLogPictureViewModel));
    this.pictures.push(this._actionLogPictureViewModel);
    console.log("Picture List : " + JSON.stringify(this.pictures));
    jQuery("#btnMDPClose").click();

  }

  addAudioToList() {

    console.log("Data Started . . .");
    this.resetActionLogPictureViewModel();
    //  this._actionLogPictureViewModel = this._actionLogViewModel;
    // console.log(this.imgData);
    //console.log((this.imgData.startsWith("data")) ? this.imgData.split(",")[1] : "");
    console.log("Audio Data : " + this.audioData);
    this._actionLogPictureViewModel.fileData = this.audioData; //(this.imgData.startsWith("data")) ? this.imgData.split(",")[1] : "";
    this._actionLogPictureViewModel.filename = this._pictureFileName;
    console.log("Data Started . . .1");
    this._actionLogPictureViewModel.description = this._pictureDescription;
    this._actionLogPictureViewModel.id = -1;
    console.log("Data " + JSON.stringify(this._actionLogPictureViewModel));
    this.audios.push(this._actionLogPictureViewModel);
    console.log("Picture List : " + JSON.stringify(this.audios));
    jQuery("#btnMDAClose").click();

  }

  addVideoToList() {

    console.log("Data Started . . .");
    this.resetActionLogPictureViewModel();
    console.log("Video Data : " + this.videoData);
    this._actionLogPictureViewModel.fileData = this.videoData;
    this._actionLogPictureViewModel.filename = this._pictureFileName;
    console.log("Data Started . . .1");
    this._actionLogPictureViewModel.description = this._pictureDescription;
    this._actionLogPictureViewModel.id = -1;
    console.log("Data " + JSON.stringify(this._actionLogPictureViewModel));
    this.videos.push(this._actionLogPictureViewModel);
    console.log("Video List : " + JSON.stringify(this.audios));
    jQuery("#btnMDVClose").click();

  }


  saveAction() {

    if (this._actionLogViewModel.id == 0) {
      this._actionLogViewModel.id = -1;
    }
    this._actionLogViewModel.caseMaster = { "id": this._caseId };
    this._actionLogViewModel.actionVersion = (this.getVersion("Action") != -1) ? this._actionVersion : 0;
    this.resetActionLogFileViewModel();

    //console.log("caseAction : " + JSON.stringify(this._actionLogViewModel));
    try {

      switch (this._actionLogViewModel.actionType) {
        case "O":
          {
            this.SaveActionByCategory(this._actionLogViewModel);
          }
          break;
        case "P":
          {
            // console.log("Data Started . . .");
            // this.resetActionLogPictureViewModel();
            // //  this._actionLogPictureViewModel = this._actionLogViewModel;
            // console.log(this.imgData);
            // console.log((this.imgData.startsWith("data")) ? this.imgData.split(",")[1] : "");
            // this._actionLogPictureViewModel.fileData = (this.imgData.startsWith("data")) ? this.imgData.split(",")[1] : "";
            // this._actionLogPictureViewModel.fileName = this._pictureFileName;
            // console.log("Data Started . . .1");
            // this._actionLogPictureViewModel.description = this._pictureDescription;
            // this._actionLogPictureViewModel.id = -1;
            // console.log("Data " + JSON.stringify(this._actionLogPictureViewModel));

            // this.pictures.push(this._actionLogPictureViewModel);
            this._actionLogViewModel.caseActionFiles = [];
            this.pictures.forEach(e => {
              if (e.fileData != null) {
                e.fileData = (e.fileData.startsWith("data")) ? e.fileData.split(",")[1] : ""
              }
              this._actionLogViewModel.caseActionFiles.push(e);
            });
            this.audios.forEach(e => {
              if (e.fileData != null) {
                e.fileData = (e.fileData.startsWith("data")) ? e.fileData.split(",")[1] : ""
              }
              this._actionLogViewModel.caseActionFiles.push(e);
            });
            this.videos.forEach(e => {
              if (e.fileData != null) {
                e.fileData = (e.fileData.startsWith("data")) ? e.fileData.split(",")[1] : ""
              }
              this._actionLogViewModel.caseActionFiles.push(e);
            });
            // this._actionLogViewModel.caseActionFiles = this.pictures;
            console.log("Picture JSON : " + JSON.stringify(this._actionLogViewModel));
            this.SaveActionByCategory(this._actionLogViewModel);
          }
          break;
        case "F":
          {
            // this._actionLogFileViewModel = this._actionLogViewModel;
            this._actionLogFileViewModel.fileData = (this._actionFileContentAsString.startsWith("data")) ? this._actionFileContentAsString.split(",")[1] : "";
            this._actionLogFileViewModel.fileName = this._actionFileName;
            this._actionLogFileViewModel.phone = "";
            this._actionLogFileViewModel.physicalFileName = "";
            console.log(JSON.stringify(this._actionLogFileViewModel));
            this.SaveActionByCategory(this._actionLogFileViewModel);
          }
          break;
        case "C":
          {

            this._citationViewModel.id = this._actionLogViewModel.id;
            this._citationViewModel.actionCode = this._actionLogViewModel.actionCode;
            this._citationViewModel.actionDate = this._actionLogViewModel.actionDate;
            this._citationViewModel.actionType = this._actionLogViewModel.actionType;
            this._citationViewModel.actionVersion = this._actionLogViewModel.actionVersion;
            this._citationViewModel.caseMaster = this._actionLogViewModel.caseMaster;
            this._citationViewModel.comments = this._actionLogViewModel.comments;
            this._citationViewModel.readDate = this._actionLogViewModel.readDate;
            this._citationViewModel.routeToInspectorId = this._actionLogViewModel.routeToInspectorId;
            this._citationViewModel.isRead = this._actionLogViewModel.isRead;
            this._citationViewModel.createdBy = this._actionLogViewModel.createdBy;
            this._citationViewModel.createdOn = this._actionLogViewModel.createdOn;
            this._citationViewModel.modifiedBy = this._actionLogViewModel.modifiedBy;
            this._citationViewModel.modifiedOn = this._actionLogViewModel.modifiedOn;
            this._citationViewModel.status = this._actionLogViewModel.status;
            console.log("Action Log Citiation : " + JSON.stringify(this._citationViewModel));
            this.SaveActionByCategory(this._citationViewModel);
          }
          break;
        case "T":
          {
            this._actionLogTypeViewModel.id = this._actionLogViewModel.id;
            this._actionLogTypeViewModel.actionCode = this._actionLogViewModel.actionCode;
            this._actionLogTypeViewModel.actionDate = this._actionLogViewModel.actionDate;
            this._actionLogTypeViewModel.actionType = this._actionLogViewModel.actionType;
            this._actionLogTypeViewModel.actionVersion = this._actionLogViewModel.actionVersion;
            this._actionLogTypeViewModel.caseMaster = this._actionLogViewModel.caseMaster;
            this._actionLogTypeViewModel.comments = this._actionLogViewModel.comments;
            this._actionLogTypeViewModel.readDate = this._actionLogViewModel.readDate;
            this._actionLogTypeViewModel.routeToInspectorId = this._actionLogViewModel.routeToInspectorId;
            this._actionLogTypeViewModel.isRead = this._actionLogViewModel.isRead;
            this._actionLogTypeViewModel.createdBy = this._actionLogViewModel.createdBy;
            this._actionLogTypeViewModel.createdOn = this._actionLogViewModel.createdOn;
            this._actionLogTypeViewModel.modifiedBy = this._actionLogViewModel.modifiedBy;
            this._actionLogTypeViewModel.modifiedOn = this._actionLogViewModel.modifiedOn;
            this._actionLogTypeViewModel.status = this._actionLogViewModel.status;
            console.log("Action Log Type : " + JSON.stringify(this._actionLogTypeViewModel));
            this.SaveActionByCategory(this._actionLogTypeViewModel);
            break;
          }
        case "A":
          {
            this._actionLogAppointmentViewModel.id = this._actionLogViewModel.id;
            this._actionLogAppointmentViewModel.actionCode = this._actionLogViewModel.actionCode;
            this._actionLogAppointmentViewModel.actionDate = this._actionLogViewModel.actionDate;
            this._actionLogAppointmentViewModel.actionType = this._actionLogViewModel.actionType;
            this._actionLogAppointmentViewModel.actionVersion = this._actionLogViewModel.actionVersion;
            this._actionLogAppointmentViewModel.caseMaster = this._actionLogViewModel.caseMaster;
            this._actionLogAppointmentViewModel.comments = this._actionLogViewModel.comments;
            this._actionLogAppointmentViewModel.readDate = this._actionLogViewModel.readDate;
            this._actionLogAppointmentViewModel.routeToInspectorId = this._actionLogViewModel.routeToInspectorId;
            this._actionLogAppointmentViewModel.isRead = this._actionLogViewModel.isRead;
            this._actionLogAppointmentViewModel.createdBy = this._actionLogViewModel.createdBy;
            this._actionLogAppointmentViewModel.createdOn = this._actionLogViewModel.createdOn;
            this._actionLogAppointmentViewModel.modifiedBy = this._actionLogViewModel.modifiedBy;
            this._actionLogAppointmentViewModel.modifiedOn = this._actionLogViewModel.modifiedOn;
            this._actionLogAppointmentViewModel.status = this._actionLogViewModel.status;
            console.log("Action Log Type : " + JSON.stringify(this._actionLogAppointmentViewModel));
            this.SaveActionByCategory(this._actionLogAppointmentViewModel);
            break;
          }
      }

    } catch (error) {
      Lobibox.notify('error', {
        pauseDelayOnHover: true,
        continueDelayOnInactiveTab: false,
        position: 'top right',
        icon: 'bx bx-check-circle',
        msg: 'Unable to save people information. Please contact IT Helpdesk.'
      });
    }

  }


  onFileChange(event: any) {
    this._actionFileName = event.target.files[0].name;
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      this._actionFileContentAsString = reader.result as string;
      console.log(this._actionFileContentAsString);
    }
    if (file) {
      reader.readAsDataURL(file);
    }
  }




  SaveActionByCategory(entity: any) {
    this._complaintServiceCall.saveByMethodName(this._urlConstant.CaseMasterModule, this._urlConstant.SaveAction, entity).subscribe((response) => {
      if (response.status == "SUCCESS") {
        // this.loadCaseDetail(this._caseId);
        Lobibox.notify('success', {
          pauseDelayOnHover: true,
          continueDelayOnInactiveTab: false,
          position: 'top right',
          icon: 'bx bx-check-circle',
          msg: 'Action saved successfully.'
        });
        console.log("Action Saved Response : " + JSON.stringify(response));
        jQuery("#addOrEditAction").hide();
        //jQuery("#action-list").show();
        //jQuery("#actionGrid").show();

        this._caseDetail = response.data[0];
        console.log("Save Action Response : " + JSON.stringify(response));
        this.resetActionLogViewModel();
        this._enableSave = true;
        if (entity.actionCode == "P") {
          jQuery("#btnMDPClose").click();
        }
        jQuery('.nav-tabs a[href="#action-list"]').tab('show');
      } else {
        let err: [] = JSON.parse(response.errorMessage);
        let errM: any = err.join('<br/>');
        Lobibox.notify('error', {
          pauseDelayOnHover: true,
          continueDelayOnInactiveTab: false,
          position: 'top right',
          icon: 'bx bx-check-circle',
          msg: 'Unable to action log.<br/>' + errM
        });
      }
    },
      (error) => {
        console.log("Error : " + JSON.stringify(error));
        Lobibox.notify('error', {
          pauseDelayOnHover: true,
          continueDelayOnInactiveTab: false,
          position: 'top right',
          icon: 'bx bx-check-circle',
          msg: 'Unable to save people information. Please contact IT Helpdesk.'
        });
      });

  }




  addNewActionLog() {
    // jQuery("#action-list").hide();
    jQuery("#action-add-edit").show();
    jQuery("#addOrEditAction").show();
    jQuery("#updateViolation").hide();
    jQuery("#followUpAction").hide();
    jQuery("#citationDetails").hide();
    jQuery("#taskDetails").hide();
    jQuery("#audio").hide();
    jQuery("#picture").hide();
    jQuery("#video").hide();
    jQuery("#appointmentInformations").hide();
    // jQuery("#actionGrid").hide();
    jQuery("#navigationAction").hide();
    jQuery('.nav-tabs a[href="#action-add-edit"]').tab('show');
    jQuery('.nav-tabs a[href="#actionAddOrEdit"]').tab('show');
    this.resetActionLogViewModel();

  }

  cancelAction() {
    jQuery("#addOrEditAction").hide();
    //jQuery("#action-add-edit").hide();
    //jQuery("#action-list").show();
    //jQuery("#actionGrid").show();
    jQuery('.nav-tabs a[href="#action-list"]').tab('show');
    jQuery("#updateViolation").hide();
    jQuery("#followUpAction").hide();
    jQuery("#navigationAction").show();
    this.resetActionLogViewModel();
  }


  addNewPicture() {
    this.imgData = "";
    this._pictureDescription = "";
    jQuery("#pictureUploadMDL").modal("show");
  }

  addNewAudio() {
    this.audioData = "";
    this._pictureDescription = "";
    jQuery("#audioUploadMDL").modal("show");
  }

  addNewVideo() {
    this.videoData = "";
    this._pictureDescription = "";
    jQuery("#videoUploadMDL").modal("show");
  }

  onPictureChange(event: any) {
    this._pictureFileName = event.target.files[0].name;
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      this.imgData = reader.result as string;
      console.log(this.imgData);
    }
    if (file) {
      reader.readAsDataURL(file);
    }
  }

  onAudioChange(event: any) {
    this._pictureFileName = event.target.files[0].name;
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      this.audioData = reader.result as string;
      console.log(this.audioData);
    }
    if (file) {
      reader.readAsDataURL(file);
    }
  }

  onVideoChange(event: any) {
    this._pictureFileName = event.target.files[0].name;
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      this.videoData = reader.result as string;
      console.log(this.videoData);
    }
    if (file) {
      reader.readAsDataURL(file);
    }
  }

  nextTab(index: any) {
    let nindex = (index + 1);
    this._currentStepIndex = nindex;
    jQuery(".bs-stepper-pane").removeClass("active");
    jQuery(".step").removeClass("active");
    jQuery(".bs-stepper-pane").removeClass("dstepper-block");
    jQuery("#step-l-" + nindex).addClass(" active ");
    jQuery("#step-l-" + nindex).addClass(" dstepper-block ");
    jQuery(".step").removeClass("active");
    $("div[data-target='#step-l-" + nindex + "']").addClass(" active ");
    jQuery("#stepper1trigger" + nindex).removeAttr("disabled");
    switch (this._currentStepIndex) {
      case 3:
        jQuery("#violation-list").show();
        jQuery("#addOrEditViolation").hide();
        jQuery("#navigationViolation").show();
        break;
      case 5:
        jQuery("#action-list").show();
        jQuery("#addOrEditAction").hide();
        jQuery("#navigationAction").show();
        break;
    }
  }

  stepClick(index: any) {
    if (jQuery("#stepper1trigger" + index).attr("disabled") == undefined) {
      jQuery(".bs-stepper-pane").removeClass("active");
      jQuery(".bs-stepper-pane").removeClass("dstepper-block");
      jQuery("#step-l-" + index).addClass(" active ");
      jQuery("#step-l-" + index).addClass(" dstepper-block ");
      jQuery("#stepper1trigger" + index).removeAttr("disabled");
      jQuery(".step").removeClass("active");
      $("div[data-target='#step-l-" + index + "']").addClass(" active ");
    }
  }

  previousTab(index: any) {
    let pindex = (index - 1);
    this._currentStepIndex = pindex;
    jQuery(".bs-stepper-pane").removeClass("active");
    jQuery(".bs-stepper-pane").removeClass("dstepper-block");
    jQuery("#step-l-" + pindex).addClass(" active ");
    jQuery("#step-l-" + pindex).addClass(" dstepper-block ");
    jQuery(".step").removeClass("active");
    $("div[data-target='#step-l-" + pindex + "']").addClass(" active ");
  }

  viewMap() {
    if (jQuery("#googleMap").hasClass("d-none")) {
      jQuery("#googleMap").removeClass("d-none");
      jQuery("#btnMap").text("Hide Map");
    } else {
      jQuery("#googleMap").addClass("d-none");
      jQuery("#btnMap").text("View Map");
    }

  }

  showCaseHistory() {
    if (jQuery("#caseHistoryList").hasClass("d-none")) {
      jQuery("#caseHistoryList").removeClass("d-none");
      jQuery("#btnCaseHistory").text("Hide Case History");
    } else {
      jQuery("#caseHistoryList").addClass("d-none");
      jQuery("#btnCaseHistory").text("View Case History");
    }

    jQuery("#btnMap").text("View Map");

  }
  nextPeople() {
    stepper1.next();
    jQuery("#btnSaveAll").removeClass("d-none");
    jQuery("#autoSave").removeClass("d-none");
  }
  addNew() {
    this.resetMockViewModel();
    jQuery("#itemInfo").modal("show");
  }
  addNewPerson() {
    if (this._isEdit) {

      this._messageText = "Do you want to cancel current editing with this action?";
      this._actionType = this._newPersonAction;
      jQuery("#messageEditDialogBox").modal("show");
      return;
    }
    jQuery("#personList").show();
    jQuery("#addOrEditPerson").show();
    jQuery("#navigationPerson").hide();
    jQuery('.nav-tabs a[href="#person-add-edit"]').tab('show');
    this.resetCasePersonViewModel();
    this._isEdit = true;
  }
  addNewViolation() {
    if (this._isEdit) {

      this._messageText = "Do you want to cancel current editing with this action?";
      this._actionType = this._newViolationAction;
      jQuery("#messageEditDialogBox").modal("show");
      return;
    }
    jQuery("#violationGrid").show();
    jQuery("#addOrEditViolation").show();
    jQuery('#violation-add-edit').show();
    jQuery("#navigationViolation").hide();
    jQuery('.nav-tabs a[href="#violation-add-edit"]').tab('show');
    this.resetViolationViewModel();
    this._isEdit = true;
  }



  actionTab(index: any) {
    switch (index) {
      case 1:
        jQuery("#tab1").show();
        jQuery("#tab2").hide();
        jQuery("#tab3").hide();
        break;
      case 2:
        jQuery("#tab1").hide();
        jQuery("#tab2").show();
        jQuery("#tab3").hide();
        break;
      case 3:
        jQuery("#tab1").hide();
        jQuery("#tab2").hide();
        jQuery("#tab3").show();
        break;

    }
  }
  edit(item: any) {
    this._mockupViewModel = item;
    jQuery("#itemInfo").modal("show");
  }
  editPerson(person: any) {
    this._editData = person;
    if (this._isEdit) {

      this._messageText = "Do you want to cancel current editing with this action?";
      this._actionType = this._editPersonAction;
      jQuery("#messageEditDialogBox").modal("show");
      return;
    }
    this._isEdit = true;
    this._casePersonViewModel = person;
    this._casePersonViewModel.personVersion = (this.getVersion("Person") != -1) ? this._personVersion : 0;

  }
  editPersonForTable() {
    let d = this._personTable.rows('.selected');
    if (this.isNull(d) || d.length == 0) {
      alert("Please select person to edit.");
      return;
    }
    let data = d.data();

    if (this._isEdit) {

      this._messageText = "Do you want to cancel current editing with this action?";
      this._actionType = this._editPersonAction;
      jQuery("#messageEditDialogBox").modal("show");
      return;
    }
    this._casePersonViewModel = this._personDataList.find((x: any) => x.id == data[0].id);
    this._casePersonViewModel.personVersion = (this.getVersion("Person") != -1) ? this._personVersion : 0;

    jQuery("#personList").show();
    jQuery("#addOrEditPerson").show();
    jQuery("#navigationPerson").hide();
    jQuery('.nav-tabs a[href="#person-add-edit"]').tab('show');
    this._isEdit = true;
  }
  _editData: any;
  editViolation(violation: any) {
    this._editData = violation;
    if (this._isEdit) {

      this._messageText = "Do you want to cancel current editing with this action?";
      this._actionType = this._editVilationAction;
      jQuery("#messageEditDialogBox").modal("show");
      return;
    }
    this._caseViolationViewModel = violation;
    this._caseViolationViewModel.inspectionVersion = (this.getVersion("Violation") != -1) ? this._violationVersion : 0;
    console.log("Violation Save : " + JSON.stringify(this._caseViolationViewModel));
    // jQuery("#violationGrid").hide();
    // jQuery("#frmViolation").show();
    // jQuery("#navigationViolation").hide();

    jQuery("#violationGrid").show();
    jQuery("#addOrEditViolation").show();
    jQuery('#violation-add-edit').show();
    jQuery("#navigationPerson").hide();
    jQuery('.nav-tabs a[href="#violation-add-edit"]').tab('show');
    this._isEdit = true;
  }


  getVersion(module: string) {
    let versionList = []
    if (this._caseDetail.caseVersions != undefined) {
      versionList = this._caseDetail.caseVersions;
      for (var i = 0; i < versionList.length; i++) {
        switch (module) {
          case "Person":
            this._personVersion = versionList[i].version;
            if (versionList[i].objecttype == module) {
              return this._personVersion;
            }
            break;
          case "Violation":
            this._violationVersion = versionList[i].version;
            if (versionList[i].objecttype == module) {
              return this._violationVersion;
            }
            break;
          case "Action":
            this._actionVersion = versionList[i].version;
            if (versionList[i].objecttype == module) {
              return this._actionVersion;
            }
            break;
        }
      }
    }
    return -1;
  }
  removePersonForTable() {
    let d = this._personTable.rows('.selected');
    if (this.isNull(d)) {
      return;
    }
    let data = d.data();
    let person = this._personDataList.find((x: any) => x.id == data[0].id);
    if (confirm("Are you sure to remove " + person.firstname + " ?")) {

      console.log("Person : " + JSON.stringify(person));

      this._complaintServiceCall.getByID(this._urlConstant.CaseMasterModule, this._urlConstant.GetByID, this._caseId).subscribe((response) => {
        if (response.status == "SUCCESS") {
          let versionList = []
          versionList = response.data[0].caseVersions;
          for (var i = 0; i < versionList.length; i++) {
            switch (versionList[i].objecttype) {
              case "Person":
                this._personVersion = versionList[i].version;
                {
                  this._complaintServiceCall.removeByMethodNameAndID(this._urlConstant.CaseMasterModule, this._urlConstant.RemovePerson, "id=" + this._caseId + "&personId=" + person.id + "&version=" + this._personVersion).subscribe((response) => {
                    this._addressSearchResultDataList = [];
                    if (response.status == "SUCCESS") {
                      Lobibox.notify('success', {
                        pauseDelayOnHover: true,
                        continueDelayOnInactiveTab: false,
                        position: 'top right',
                        icon: 'bx bx-check-circle',
                        msg: 'Person Removed Successfully.'
                      });
                      this._caseDetail = response.data[0];
                      this._personDataList = (this._caseDetail.casePerson.filter((e: any) => e.status));
                      this._personTable.clear().rows.add(this._personDataList).draw();
                    } else {
                      Lobibox.notify('error', {
                        pauseDelayOnHover: true,
                        continueDelayOnInactiveTab: false,
                        position: 'top right',
                        icon: 'bx bx-check-circle',
                        msg: 'Unable to remove person. Please contact IT Helpdesk.'
                      });
                    }
                  });
                }
                break;
            }
          }
        } else {
          Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Unable to receive case details. Please contact IT Helpdesk.'
          });
        }
      });



    }
  }
  removePerson(person: any) {
    if (confirm("Are you sure to remove " + person.firstname + " ?")) {

      console.log("Person : " + JSON.stringify(person));

      this._complaintServiceCall.getByID(this._urlConstant.CaseMasterModule, this._urlConstant.GetByID, this._caseId).subscribe((response) => {
        if (response.status == "SUCCESS") {
          let versionList = []
          versionList = response.data[0].caseVersions;
          for (var i = 0; i < versionList.length; i++) {
            switch (versionList[i].objecttype) {
              case "Person":
                this._personVersion = versionList[i].version;
                {
                  this._complaintServiceCall.removeByMethodNameAndID(this._urlConstant.CaseMasterModule, this._urlConstant.RemovePerson, "id=" + this._caseId + "&personId=" + person.id + "&version=" + this._personVersion).subscribe((response) => {
                    this._addressSearchResultDataList = [];
                    if (response.status == "SUCCESS") {
                      Lobibox.notify('success', {
                        pauseDelayOnHover: true,
                        continueDelayOnInactiveTab: false,
                        position: 'top right',
                        icon: 'bx bx-check-circle',
                        msg: 'Person Removed Successfully.'
                      });
                      //this.loadCaseDetail(this._caseId);
                    } else {
                      Lobibox.notify('error', {
                        pauseDelayOnHover: true,
                        continueDelayOnInactiveTab: false,
                        position: 'top right',
                        icon: 'bx bx-check-circle',
                        msg: 'Unable to remove person. Please contact IT Helpdesk.'
                      });
                    }
                  });
                }
                break;
            }
          }
        } else {
          Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: 'Unable to receive case details. Please contact IT Helpdesk.'
          });
        }
      });



    }

  }

  resetReport() {
    jQuery("#caseHistoryReport").hide();
    jQuery("#propertyAndCaseHistory").hide();
  }



  loadInfo() {
    jQuery("#caseHistoryReport").show();
    jQuery("#propertyAndCaseHistory").show();
  }

  display: any;
  center: google.maps.LatLngLiteral = {
    lat: 24,
    lng: 12
  };
  zoom = 4;
  moveMap(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) this.center = (event.latLng.toJSON());
  }
  move(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) this.display = event.latLng.toJSON();
  }


}
